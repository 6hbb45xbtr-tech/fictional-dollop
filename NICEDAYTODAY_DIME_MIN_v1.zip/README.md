# NICEDAYTODAY — Dime (Minimal)
- Frontend (Netlify): `/frontend`
- Backend (Render): `/backend` with /qr only (no dynamic redirect)
Use this if you want the simplest possible spin first. Upgrade to Full later.
